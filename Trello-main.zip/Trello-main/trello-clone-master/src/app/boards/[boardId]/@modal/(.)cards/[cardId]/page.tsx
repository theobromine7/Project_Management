import CardModal from "@/components/views/CardModal";

export default function CardModalPage() {
  return (
    <CardModal />
  );
}